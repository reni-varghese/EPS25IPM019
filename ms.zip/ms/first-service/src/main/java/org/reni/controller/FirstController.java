package org.reni.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirstController {

    @Value("${first.message}")
    private String message;
    private final Environment env;
    public FirstController(Environment env) {
        this.env = env;
    }

    @GetMapping("/first")
    public String getFirst(){
        return  message+" " +env.getProperty("server.port");
    }
}
