package org.reni.controller;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import org.reni.client.FirstClient;
import org.reni.client.SecondClient;
import org.reni.service.DataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
@RequiredArgsConstructor

public class ClientController {



    Logger logger = LoggerFactory.getLogger(ClientController.class);


    private final DataService dataService;


    @GetMapping("/messages")

    public String getMessages(){

     return dataService.fetchBoth();

    }



}
