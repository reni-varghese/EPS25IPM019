package org.reni.service;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.reni.client.FirstClient;
import org.reni.client.SecondClient;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataService {

    private final FirstClient firstClient;
    private final SecondClient  secondClient;



    @CircuitBreaker(name="second-service",fallbackMethod = "myFallback")
    public String fetchBoth(){
        String first=firstClient.getFirst();
        log.info("Calling Second service ========================");
        String second=secondClient.getSecond();
        return first+" "+second;
    }

    public String myFallback(Throwable throwable){
        String first=firstClient.getFirst();
        return first+" "+"default Response";
    }
}
