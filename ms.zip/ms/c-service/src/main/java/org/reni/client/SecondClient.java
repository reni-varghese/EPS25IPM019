package org.reni.client;

import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="second-service")
@Retry(name="default")
public interface SecondClient {
    @GetMapping("/second")
    public String getSecond();


}
