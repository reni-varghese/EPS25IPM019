package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.cts.clients.FirstClient;
import com.cts.clients.SecondClient;

@Service
public class DataService {

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private RestClient.Builder restClientBuiler;
	@Autowired
	private WebClient.Builder webClientBuilder;
	@Autowired
	private FirstClient firstClient;
	@Autowired
	private SecondClient secondClient;
	
	
	public String fetchBoth() {
		
//		String first = restTemplate.getForObject
//				("http://localhost:8081/first", String.class);
//		String second=
//				restTemplate.getForObject("http://localhost:8082/second", String.class);
		
//		String first=restClientBuiler.build()
//		.get().uri("http://first-service/first")
//		.retrieve()
//		.body(String.class);
//		String second=restClientBuiler.build()
//				.get().uri("http://second-service/second")
//				.retrieve()
//				.body(String.class);
//		
//		String first=webClientBuilder.build()
//				.get().uri("http://first-service/first")
//				.retrieve()
//				.bodyToMono(String.class).block();
//		String second=webClientBuilder.build()
//				.get().uri("http://second-service/second")
//				.retrieve()
//				.bodyToMono(String.class).block();
		
		String first=firstClient.showFirst();
		String second=secondClient.showSecond();
		
		return first+" "+second;
	}
}
