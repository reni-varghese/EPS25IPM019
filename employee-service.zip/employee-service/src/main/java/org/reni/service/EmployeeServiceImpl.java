package org.reni.service;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.reni.dtos.EmployeeDto;
import org.reni.entity.Employee;
import org.reni.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final ModelMapper modelMapper;

    @Override
    public List<EmployeeDto> getAllEmployees() {
        return employeeRepository
                .findAll()
                .stream()
                .map(emp->
                        modelMapper.map(emp, EmployeeDto.class))
                .toList();
    }

    @Override
    public EmployeeDto addEmployee(EmployeeDto employeeDto) {
        return modelMapper.map(
                employeeRepository.save(
                        modelMapper.map(employeeDto, Employee.class)
                ), EmployeeDto.class
        );
    }
}
