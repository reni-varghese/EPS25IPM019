package com.cts.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.service.DataService;

@RestController
public class ClientController {

	@Autowired
	private DataService dataService;
	@GetMapping("/report")
	public Map<String,String> getMessages() {
		
		Map<String,String> result = new HashMap<>();
		
		var msg1 = dataService.getWeatherMessage();
		result.put("Weather",msg1.get("weather"));
		
		var msg2 = dataService.getNewsMessage();
		result.put("News", msg2.get("news"));
		
		return result;
	}
}
