package com.cts.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestClient;
//import org.springframework.web.client.RestTemplate;
//import org.springframework.web.reactive.function.client.WebClient;

import com.cts.clients.NewsClient;
import com.cts.clients.WeatherClient;

import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DataService {
	


//	@Autowired
//	private RestTemplate restTemplate;
//	
//	@Autowired
//	private RestClient.Builder restClientBuilder;
//	
//	@Autowired
//	private WebClient.Builder webClientBuilder;
	
	@Autowired
	private WeatherClient weatherClient;
	
	@Autowired
	private NewsClient newsClient;
	
//	public String fetchBoth() {
		
//		String weather = restTemplate
//				.getForObject
//				("http://localhost:8081/weather",String.class);
//	
//		String news = restTemplate
//		.getForObject
//		("http://localhost:8082/news", String.class);
		
//		String weather = restClientBuilder.build()
//		.get().uri("http://weather-service/weather")
//		.retrieve()
//		.body(String.class);
//		
//		String news = restClientBuilder.build()
//				.get().uri("http://news-service/news")
//				.retrieve()
//				.body(String.class);
		
//		String weather = webClientBuilder.build()
//				.get().uri("http://weather-service/weather")
//				.retrieve()
//				.bodyToMono(String.class).block();
//				
//				String news = webClientBuilder.build()
//						.get().uri("http://news-service/news")
//						.retrieve()
//						.bodyToMono(String.class).block();
		
		
		
//		return weather +" " + news;
//	}
	
	Map<String,String> map = new HashMap<>();
//	public Map<String,String> fetchBoth() {
//		//Using FeignClient
//		
//				String weather = weatherClient.showWeather();
//				map.put("weather", weather);
//				String news = newsClient.showNews();
//				map.put("news", news);
//		return map;
//	}
	
	
	public Map<String,String> getWeatherMessage(){
		String weather = weatherClient.showWeather();
		map.put("weather", weather);
		return map;
	}	
	
	@Retry( name = "news-service",fallbackMethod = "defaultResponse")
	public Map<String,String> getNewsMessage(){
		log.info("News Service is getting called ===================");
		String news = newsClient.showNews();
		map.put("news", news);
		return map;
	}
	public Map<String,String> getNewsMessage(Throwable throwable){
		
		Map<String, String> res = new HashMap<>();
		res.put("news", "Service Not available");
		return res;
		
		
	}
	
}
