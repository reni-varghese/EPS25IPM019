package com.cts.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="weather-service")
public interface WeatherClient {
	@GetMapping("/weather")
	public String showWeather();
}
