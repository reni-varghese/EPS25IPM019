package com.cts.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NewsController {

	@GetMapping("/news")
	public String showNews() {
		return "Breaking News: Stock market hit a new high";
	}
}
