package com.cts.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirstController {
	@Autowired
	private Environment env;
	@Value("${app.first.message}")
	private String message;

	@GetMapping("/first")
	public String showFirst() {
		return message+" "+env.getProperty("server.port");
	}
}
